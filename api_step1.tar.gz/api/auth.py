"""
Авторизация через Telegram WebApp.

Telegram передаёт в Mini App строку initData с подписью HMAC-SHA256.
Мы проверяем подпись секретом бота — это гарантирует что данные
действительно от Telegram, а не подделаны клиентом.

Документация: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
"""
import hashlib
import hmac
import json
import logging
import time
from urllib.parse import parse_qsl

from fastapi import Header, HTTPException, status
from sqlalchemy import select

from config import settings
from db import get_session
from models import User

logger = logging.getLogger(__name__)

# Срок действия initData — Telegram рекомендует не дольше 24 часов
MAX_INIT_DATA_AGE_SECONDS = 24 * 60 * 60


def verify_telegram_init_data(init_data: str) -> dict:
    """
    Проверяет HMAC-подпись initData и возвращает распарсенные данные пользователя.
    Бросает HTTPException если подпись невалидна или данные устарели.
    """
    try:
        parsed = dict(parse_qsl(init_data, strict_parsing=True))
    except ValueError:
        raise HTTPException(401, "Invalid initData format")

    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "Missing hash in initData")

    # Проверка возраста
    auth_date = int(parsed.get("auth_date", 0))
    if time.time() - auth_date > MAX_INIT_DATA_AGE_SECONDS:
        raise HTTPException(401, "initData expired")

    # Telegram строит data-check-string как key=value\nkey=value... (отсортировано)
    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))

    # Секрет = HMAC-SHA256(bot_token, "WebAppData")
    secret_key = hmac.new(
        b"WebAppData", settings.BOT_TOKEN.encode(), hashlib.sha256
    ).digest()
    expected_hash = hmac.new(
        secret_key, data_check_string.encode(), hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(expected_hash, received_hash):
        raise HTTPException(401, "Invalid initData signature")

    user_json = parsed.get("user")
    if not user_json:
        raise HTTPException(401, "User not in initData")

    try:
        user_data = json.loads(user_json)
    except json.JSONDecodeError:
        raise HTTPException(401, "Invalid user JSON")

    return user_data


async def get_current_user(
    x_telegram_init_data: str = Header(..., alias="X-Telegram-Init-Data")
) -> User:
    """
    FastAPI dependency. Извлекает пользователя из заголовка X-Telegram-Init-Data.
    Если пользователь не зарегистрирован — 403.
    """
    tg_user = verify_telegram_init_data(x_telegram_init_data)
    telegram_id = tg_user.get("id")
    if not telegram_id:
        raise HTTPException(401, "No telegram_id in initData")

    async with get_session() as db:
        result = await db.execute(
            select(User).where(User.telegram_id == int(telegram_id))
        )
        user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Не зарегистрированы. Откройте бота и пройдите регистрацию по ИНН.",
        )
    if user.status != "active":
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            f"Аккаунт в статусе {user.status}",
        )
    return user
